// src/components/LoginSignup.js
import React, { useState } from 'react';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import { TextField, Button, Typography, Link, Box } from '@mui/material';
import { useAuth } from '../contexts/AuthContext';

const LoginSignup = () => {
  const { login } = useAuth();
  const [credentials, setCredentials] = useState({ username: '', email: '', password: '', Confirm_Password: '' });
  const [passwordError, setPasswordError] = useState('');
  const [emailError, setEmailError] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Credentials:', credentials);

    const validateEmail = (email) => /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/.test(email);

    if (!validateEmail(credentials.email)) {
      setEmailError('Invalid email format');
      return;
    }

    if (credentials.password !== credentials.Confirm_Password) {
      setPasswordError("Passwords don't match");
      return;
    }

    login(credentials.username);
    navigate('/');
  };

  return (
    <div
      style={{
        backgroundSize: 'cover',
        backgroundRepeat: 'no-repeat',
        height: '100vh',
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <div style={{
        width: '50%', 
        display: 'flex',
        justifyContent: 'center', 
        alignItems: 'center', 
      }}>
        <img
          src='https://img.freepik.com/free-vector/businessman-sets-goals-runs-up-graph-columns-success-time-self-management-self-regulation-learning-self-organization-course-concept_335657-359.jpg?t=st=1721929993~exp=1721933593~hmac=6c8059373796579be766089b76fa546a9c8834519b3facf5e810676d4d073e5d&w=996'
          alt='logo'
          style={{
            height: "50%",
            borderRadius: "10px",
            margin: "10px",
            width: "800px",
          }}
        />
      </div>
      <div style={{
        width: '50%',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
      }}>
        <Box
          sx={{
            width: '100%',
            maxWidth: '400px',
            p: 3,
            border: '2px solid #D3D3D3',
            borderRadius: '10px',
            backgroundColor: '#f0f0',
            boxShadow: 3
          }}
        >
          <Typography component="h1" variant="h5" sx={{ mb: 2 }}>Sign Up</Typography>

          <form onSubmit={handleSubmit} style={{ width: '100%' }}>
            <TextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              id="username"
              label="Username"
              name="username"
              autoComplete="username"
              value={credentials.username}
              onChange={handleChange}
            />
            <TextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              id="email"
              label="Email"
              name="email"
              autoComplete="email"
              error={!!emailError}
              helperText={emailError}
              value={credentials.email}
              onChange={handleChange}
            />
            <TextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              name="password"
              label="Password"
              type="password"
              id="password"
              autoComplete="current-password"
              value={credentials.password}
              onChange={handleChange}
            />
            <TextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              id="Confirm_Password"
              label="Confirm Password"
              name="Confirm_Password"
              type="password"
              error={!!passwordError}
              helperText={passwordError}
              autoComplete="Confirm_Password"
              value={credentials.Confirm_Password}
              onChange={handleChange}
            />
            <Button type="submit" fullWidth variant="contained" sx={{ mt: 3, mb: 2, backgroundColor: 'black' }}>
              Sign Up
            </Button>
            <Typography variant="body2" color="textSecondary" sx={{ mt: 1 }}>
              Already have an account?{' '}
              <Link
                component={RouterLink}
                to="/login"
                color="primary"
                sx={{ textDecoration: 'none' }}
              >
                Login here
              </Link>
            </Typography>
          </form>
        </Box>
      </div>
    </div>
  );
};

export default LoginSignup;
