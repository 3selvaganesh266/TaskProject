import React from 'react';
import Navbars from "../Navbar/Navbars";
import { useNavigate } from 'react-router-dom';
import '../../Assets/Styles/home.css';
import { useAuth } from "../contexts/AuthContext";
import Mainpage from './Mainpage';
import Footer from './footer';

const HomePage = () => {
  const navigate = useNavigate();
  const { isAuthenticated, username } = useAuth(); 

  const handleCardClick = (path) => {
    navigate(path);
  };

  return (
    <div>
      <Navbars />
      <div className="home-container">
        {!isAuthenticated ? (
          <>
            <div className="text-section">
              <h1>Welcome to TimeSync</h1>
              <p>Seamlessly manage tasks and projects: Get assignments, track progress, and update status to keep projects on schedule and organized. Explore the features and get started!</p>
              <button onClick={() => navigate('/explore')}>
                Explore Features
              </button>
            </div>
            <div className="image-section">
              <img
                src='https://img.freepik.com/free-vector/businessman-sets-goals-runs-up-graph-columns-success-time-self-management-self-regulation-learning-self-organization-course-concept_335657-359.jpg?t=st=1721929993~exp=1721933593~hmac=6c8059373796579be766089b76fa546a9c8834519b3facf5e810676d4d073e5d&w=996'
                alt='logo'
              />
            </div>
          </>
        ) : (
          <Mainpage/>
        )}
      </div>
      <div>
         
         // I need some contest in right and some images in left;
      </div>
    </div>
  );
};

export default HomePage;
