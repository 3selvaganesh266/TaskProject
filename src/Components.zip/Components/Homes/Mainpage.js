import { useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import '../../Assets/Styles/Mainpage.css';

const Mainpage = () => {
    const navigate = useNavigate();
    const { isAuthenticated, username } = useAuth(); 

    const handleCardClick = (path) => {
        navigate(path);
    };

    return (
        <div className="mainpage-container">
            <div className="welcome-box">
                <h2 className="welcome-text">
                    <span>Hello {username}! 👋</span>
                    <small>This is a platform where you can be punctual and disciplined in your work.</small>
                </h2>
            </div>
            <div className="cards-container">
                <div className="card" onClick={() => handleCardClick('/tasks')}>
                    <img src="path/to/task-logo.png" alt="Task Logo" className="card-logo"/>
                    <h2 className="card-header">TASKS</h2>
                    <p className="card-description">Manage your tasks efficiently and keep track of deadlines.</p>
                </div>
                <div className="card" onClick={() => handleCardClick('/projects')}>
                    <img src="path/to/project-logo.png" alt="Project Logo" className="card-logo"/>
                    <h2 className="card-header">PROJECTS</h2>
                    <p className="card-description">Organize your projects and collaborate with your team effectively.</p>
                </div>
            </div>
            <div className="additional-content">
                <div className="content-section left">
                    <img src="path/to/left-image.jpg" alt="Left Image" className="side-image"/>
                    <p className="content-text">This section contains information about productivity tips and tools that can help you stay on track with your tasks and projects.</p>
                </div>
                <div className="content-section right">
                    <img src="path/to/right-image.jpg" alt="Right Image" className="side-image"/>
                    <p className="content-text">Explore various strategies for efficient project management and learn how to collaborate effectively with your team.</p>
                </div>
            </div>
        </div>
    );
};

export default Mainpage;
