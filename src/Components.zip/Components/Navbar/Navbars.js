import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import '../../Assets/Styles/Navbar.css';
import profile from '../../Assets/Images/profileicon.png';

const Navbars = () => {
  const { isAuthenticated } = useAuth(); 

  return (
    <nav className="navbar">
      <div className="title">
      TIMESYNC 
      </div>
      <ul className="nav-items">
        { !isAuthenticated ? (
          <>
            <li><Link to="/howitworks">How It Works</Link></li>
            <li><Link to="/aboutus">About Us</Link></li>
            <li><Link to="/contactus">Contact Us</Link></li>
            <li><Link to="/login">Login</Link></li>
            <li><Link to="/signup">Register</Link></li>
          </>
        ) : (
          <>
            <li className="dropdown"> 
              <Link to="/coins"></Link> 
              <div className="dropdown-content">
                <Link to="/mycoins">My Coins</Link>
                <Link to="/convertcoins">Convert Coins</Link>
              </div>
            </li>
            <li><Link to="/shop"></Link></li>

            <li className="dropdown">
              <Link to="/mysubmission"></Link>
              <div className="dropdown-content">
                <Link to="/currentsubmission"></Link>
                <Link to="/pastsubmission"></Link>
              </div>
            </li>

            <li className="dropdown">
              <Link to="/submitwaste"></Link>
              <div className="dropdown-content">
                <Link to="/submitwaste/resident"></Link>
                <Link to="/submitwaste/commercial"></Link>
                <Link to="/submitwaste/ewaste"></Link>
              </div>
            </li> 

            <li><Link to="/profile">
            <img src={profile} alt="Profile" className="profile-image"/></Link>
            </li>
          </>
        )}
      </ul>
    </nav>
  );
};

export default Navbars; 

// import React from 'react';
// import { Link } from 'react-router-dom';
// import '../../assets/styles/Navbar.css';

// const Navbar = () => {
//   const isLoggedIn = false; // Placeholder: Replace with actual login state

//   return (
    
//   );
// };

// export default Navbar;