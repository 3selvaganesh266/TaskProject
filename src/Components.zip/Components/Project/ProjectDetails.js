import React, { useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import '../../Assets/Styles/ProjectDetails.css';   

const ProjectDetails = () => {
    const { username } = useAuth();
    const [selectedStatus, setSelectedStatus] = useState("completed");
    const [selectedProject, setSelectedProject] = useState(null);

    const [projects, setProjects] = useState({
        completed: [
            { hr: "Alice", name: "Project 1", deadline: "2024-08-01", status: "Completed" },
            { hr: "Bob", name: "Project 2", deadline: "2024-08-05", status: "Completed" },
            { hr: "Ivan", name: "Project 9", deadline: "2024-08-22", status: "Completed" },
        ],
        yetToDo: [
            { hr: "Charlie", name: "Project 3", deadline: "2024-08-10", status: "Yet to Do" },
            { hr: "David", name: "Project 5", deadline: "2024-08-12", status: "Yet to Do" },
            { hr: "Ella", name: "Project 7", deadline: "2024-08-15", status: "Yet to Do" },
            { hr: "Jack", name: "Project 10", deadline: "202 4-08-25", status: "Yet to do" },
        ],
        pending: [
            { hr: "Frank", name: "Project 4", deadline: "2024-08-15", status: "Pending" },
            { hr: "Grace", name: "Project 6", deadline: "2024-08-18", status: "Pending" },
            { hr: "Hannah", name: "Project 8", deadline: "2024-08-20", status: "Pending" },
        ]
    });

    const handleStatusClick = (status) => {
        setSelectedStatus(status);
        setSelectedProject(null);
    };

    const handleProjectClick = (project) => {
        setSelectedProject(project);
    };

    const handleFormSubmit = (e) => {
        e.preventDefault();

        setProjects((prevProjects) => {
            const updatedProjects = { ...prevProjects };

            // Remove project from its current status list
            const currentStatusList = updatedProjects[selectedStatus].filter(
                (project) => project.name !== selectedProject.name
            );
            updatedProjects[selectedStatus] = currentStatusList;

            // Ensure new status is valid and exists in projects object
            const newStatus = selectedProject.status.replace(/\s/g, "").toLowerCase();
            if (updatedProjects[newStatus]) {
                // Add project to its new status list
                const newStatusList = [...updatedProjects[newStatus], { ...selectedProject }];
                updatedProjects[newStatus] = newStatusList;
            }

            return updatedProjects;
        });

        setSelectedProject(null); // Close the form after submission
    };

    return (
        <div className="project-details-container">
            <div className="sidebar">
                <h2>Hello {username}! 👋</h2>
                <ul>
                    <li onClick={() => handleStatusClick("completed")}>Completed Projects</li>
                    <li onClick={() => handleStatusClick("yetToDo")}>Yet to Do</li>
                    <li onClick={() => handleStatusClick("pending")}>Pending</li>
                </ul>
            </div>
            <div className="content">
                {!selectedProject ? (
                    <div className="project-list">
                        {projects[selectedStatus].map((project, index) => (
                            <div className={`project-box ${project.status === "Completed" ? "completed" : ""}`} key={index} onClick={() => handleProjectClick(project)}>
                                <h3>{project.name}</h3>
                                <p><strong>HR:</strong> {project.hr}</p>
                                <p><strong>Deadline:</strong> {project.deadline}</p>
                                <p className="project-status">{project.status}</p>
                            </div>
                        ))}
                    </div>
                ) : (
                    <form onSubmit={handleFormSubmit} className="project-form">
                        <h3>Update Project</h3>
                        <label>
                            Name:
                            <input type="text" value={selectedProject.name} readOnly />
                        </label>
                        <label>
                            HR:
                            <input type="text" value={selectedProject.hr} readOnly />
                        </label>
                        <label>
                            Deadline:
                            <input type="date" value={selectedProject.deadline} readOnly />
                        </label>
                        <label>
                            Status:
                            <select
                                value={selectedProject.status}
                                onChange={(e) =>
                                    setSelectedProject({ ...selectedProject, status: e.target.value })
                                }
                            >
                                <option value="Completed">Completed</option>
                                <option value="Yet to Do">Yet to Do</option>
                                <option value="Pending">Pending</option>
                            </select>
                        </label>
                        <button type="submit">
                            {selectedProject.status === "Completed" ? "Project is Completed" : "Update Project"}
                        </button>
                    </form>
                )}
            </div>
        </div>
    );
};

export default ProjectDetails;
