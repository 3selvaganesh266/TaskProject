import React, { useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import '../../Assets/Styles/TaskDetails.css';

const TaskDetails = () => {
    const { username } = useAuth();
    const [selectedStatus, setSelectedStatus] = useState("completed");
    const [selectedTask, setSelectedTask] = useState(null);

    const [tasks, setTasks] = useState({
        completed: [
            { hr: "Alice", name: "Task 1", deadline: "2024-08-01", status: "Completed" },
            { hr: "Bob", name: "Task 2", deadline: "2024-08-05", status: "Completed" }
        ],
        yetToDo: [
            { hr: "Charlie", name: "Task 3", deadline: "2024-08-10", status: "Yet to Do" },
            { hr: "David", name: "Task 5", deadline: "2024-08-12", status: "Yet to Do" },
            { hr: "Ella", name: "Task 7", deadline: "2024-08-15", status: "Yet to Do" }
        ],
        pending: [
            { hr: "Frank", name: "Task 4", deadline: "2024-08-15", status: "Pending" },
            { hr: "Grace", name: "Task 6", deadline: "2024-08-18", status: "Pending" },
            { hr: "Hannah", name: "Task 8", deadline: "2024-08-20", status: "Pending" },
            { hr: "Ivan", name: "Task 9", deadline: "2024-08-22", status: "Pending" },
            { hr: "Jack", name: "Task 10", deadline: "2024-08-25", status: "Pending" }
        ]
    });

    const handleStatusClick = (status) => {
        setSelectedStatus(status);
        setSelectedTask(null);
    };

    const handleTaskClick = (task) => {
        setSelectedTask(task);
    };

    const handleFormSubmit = (e) => {
        e.preventDefault();

        setTasks((prevTasks) => {
            const updatedTasks = { ...prevTasks };

            // Remove task from its current status list
            const currentStatusList = updatedTasks[selectedStatus].filter(
                (task) => task.name !== selectedTask.name
            );
            updatedTasks[selectedStatus] = currentStatusList;

            // Ensure new status is valid and exists in tasks object
            const newStatus = selectedTask.status.replace(/\s/g, "").toLowerCase();
            if (updatedTasks[newStatus]) {
                // Add task to its new status list
                const newStatusList = [...updatedTasks[newStatus], { ...selectedTask }];
                updatedTasks[newStatus] = newStatusList;
            }

            return updatedTasks;
        });

        setSelectedTask(null); // Close the form after submission
    };

    return (
        <div className="task-details-container">
            <div className="sidebar">
                <h2>Hello {username}! 👋</h2>
                <ul>
                    <li onClick={() => handleStatusClick("completed")}>Completed Status</li>
                    <li onClick={() => handleStatusClick("yetToDo")}>Yet to Do</li>
                    <li onClick={() => handleStatusClick("pending")}>Pending</li>
                </ul>
            </div>
            <div className="content">
                {!selectedTask ? (
                    <div className="task-list">
                        {tasks[selectedStatus].map((task, index) => (
                            <div className={`task-box ${task.status === "Completed" ? "completed" : ""}`} key={index} onClick={() => handleTaskClick(task)}>
                                <h3>{task.name}</h3>
                                <p><strong>HR:</strong> {task.hr}</p>
                                <p><strong>Deadline:</strong> {task.deadline}</p>
                                <p className="task-status">{task.status}</p>
                            </div>
                        ))}
                    </div>
                ) : (
                    <form onSubmit={handleFormSubmit} className="task-form">
                        <h3>Update Task</h3>
                        <label>
                            Name:
                            <input type="text" value={selectedTask.name} readOnly />
                        </label>
                        <label>
                            HR:
                            <input type="text" value={selectedTask.hr} readOnly />
                        </label>
                        <label>
                            Deadline:
                            <input type="date" value={selectedTask.deadline} readOnly />
                        </label>
                        <label>
                            Status:
                            <select
                                value={selectedTask.status}
                                onChange={(e) =>
                                    setSelectedTask({ ...selectedTask, status: e.target.value })
                                }
                            >
                                <option value="Completed">Completed</option>
                                <option value="Yet to Do">Yet to Do</option>
                                <option value="Pending">Pending</option>
                            </select>
                        </label>
                        <button type="submit">
                            {selectedTask.status === "Completed" ? "Task is Completed" : "Update Task"}
                        </button>
                    </form>
                )}
            </div>
        </div>
    );
};

export default TaskDetails;
